ALTER TABLE `lc_categories_info` CHANGE `meta_description` `meta_description` VARCHAR(512) NOT NULL;
-- --------------------------------------------------------
ALTER TABLE `lc_manufacturers_info` CHANGE `meta_description` `meta_description` VARCHAR(512) NOT NULL;
-- --------------------------------------------------------
ALTER TABLE `lc_pages_info` CHANGE `meta_description` `meta_description` VARCHAR(512) NOT NULL;
-- --------------------------------------------------------
ALTER TABLE `lc_products_info` CHANGE `meta_description` `meta_description` VARCHAR(512) NOT NULL;
