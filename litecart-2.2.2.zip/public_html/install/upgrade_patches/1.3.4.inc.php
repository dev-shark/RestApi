<?php

  $deleted_files = array(
    FS_DIR_APP . 'ext/jqplot/plugins/jqplot.BezierCurveRenderer.min.js',
    FS_DIR_APP . 'ext/jqplot/plugins/jqplot.blockRenderer.min.js',
    FS_DIR_APP . 'ext/jqplot/plugins/jqplot.bubbleRenderer.min.js',
    FS_DIR_APP . 'ext/jqplot/plugins/jqplot.canvasAxisLabelRenderer.min.js',
    FS_DIR_APP . 'ext/jqplot/plugins/jqplot.canvasAxisTickRenderer.min.js',
    FS_DIR_APP . 'ext/jqplot/plugins/jqplot.canvasOverlay.min.js',
    FS_DIR_APP . 'ext/jqplot/plugins/jqplot.canvasTextRenderer.min.js',
    FS_DIR_APP . 'ext/jqplot/plugins/jqplot.ciParser.min.js',
    FS_DIR_APP . 'ext/jqplot/plugins/jqplot.cursor.min.js',
    FS_DIR_APP . 'ext/jqplot/plugins/jqplot.dateAxisRenderer.min.js',
    FS_DIR_APP . 'ext/jqplot/plugins/jqplot.donutRenderer.min.js',
    FS_DIR_APP . 'ext/jqplot/plugins/jqplot.dragable.min.js',
    FS_DIR_APP . 'ext/jqplot/plugins/jqplot.enhancedLegendRenderer.min.js',
    FS_DIR_APP . 'ext/jqplot/plugins/jqplot.funnelRenderer.min.js',
    FS_DIR_APP . 'ext/jqplot/plugins/jqplot.json2.min.js',
    FS_DIR_APP . 'ext/jqplot/plugins/jqplot.logAxisRenderer.min.js',
    FS_DIR_APP . 'ext/jqplot/plugins/jqplot.mekkoAxisRenderer.min.js',
    FS_DIR_APP . 'ext/jqplot/plugins/jqplot.mekkoRenderer.min.js',
    FS_DIR_APP . 'ext/jqplot/plugins/jqplot.meterGaugeRenderer.min.js',
    FS_DIR_APP . 'ext/jqplot/plugins/jqplot.mobile.min.js',
    FS_DIR_APP . 'ext/jqplot/plugins/jqplot.ohlcRenderer.min.js',
    FS_DIR_APP . 'ext/jqplot/plugins/jqplot.pieRenderer.min.js',
    FS_DIR_APP . 'ext/jqplot/plugins/jqplot.pointLabels.min.js',
    FS_DIR_APP . 'ext/jqplot/plugins/jqplot.pyramidAxisRenderer.min.js',
    FS_DIR_APP . 'ext/jqplot/plugins/jqplot.pyramidGridRenderer.min.js',
    FS_DIR_APP . 'ext/jqplot/plugins/jqplot.pyramidRenderer.min.js',
    FS_DIR_APP . 'ext/jqplot/plugins/jqplot.trendline.min.js',
    FS_DIR_APP . 'ext/jqplot/changes.txt',
    FS_DIR_APP . 'ext/jqplot/gpl-2.0.txt',
    FS_DIR_APP . 'ext/jqplot/jqPlotCssStyling.txt',
    FS_DIR_APP . 'ext/jqplot/jqPlotOptions.txt',
    FS_DIR_APP . 'ext/jquery/jquery.js',
    FS_DIR_APP . 'ext/jqplot/jquery.min.js',
    FS_DIR_APP . 'ext/jqplot/optionsTutorial.txt',
    FS_DIR_APP . 'ext/jqplot/usage.txt',
  );

  foreach ($deleted_files as $pattern) {
    if (!file_delete($pattern)) {
      die('<span class="error">[Error]</span></p>');
    }
  }
