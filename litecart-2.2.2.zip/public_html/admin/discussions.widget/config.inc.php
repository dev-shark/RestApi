<?php

  return $widget_config = array(
    'name' => language::translate('title_discussions', 'Discussions'),
    'file' => 'discussions.inc.php',
    'priority' => 4,
  );
