<?php

  return $widget_config = array(
    'name' => language::translate('title_graphs', 'Graphs'),
    'file' => 'graphs.inc.php',
    'priority' => 0,
  );
